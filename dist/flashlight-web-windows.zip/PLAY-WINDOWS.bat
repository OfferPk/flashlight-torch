@echo off
cd /d "%~dp0"
echo Offer Torch / Flashlight — opening offline UI...
start "" "index.html"
